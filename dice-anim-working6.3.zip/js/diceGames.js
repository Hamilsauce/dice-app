// need one Rules factory class  
// then a class for horses, SCC, 3s
class RuleSet {
  constructor(rulesName, game) {
    this.game = game
    this.rulesName = rulesName,
    this.rollCount = 5
  }
}

